<?php
    $conn = mysqli_connect('localhost','root','','proyectobinz');
    if(!$conn) {
        echo 'No conectado';
    }
?>
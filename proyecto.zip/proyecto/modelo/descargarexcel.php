<?php
require '../vendor/autoload.php';
require '../modelo/conexion.php';  

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

$spreadsheet = new Spreadsheet();
$hojaactiva = $spreadsheet->getActiveSheet();

$sql = "SELECT cedula, nombre, contrasena FROM usuario";
$resultado = $conn->query($sql);

if ($resultado === false) {
    die('Error en la consulta: ' . $conn->error);
}

$hojaactiva->setTitle('Usuarios');
$hojaactiva->setCellValue('A1', 'Cedula');
$hojaactiva->setCellValue('B1', 'Nombre');
$hojaactiva->setCellValue('C1', 'Contrasena');

$fila = 2;
while ($row = $resultado->fetch_assoc()) {
    $hojaactiva->setCellValue('A'.$fila, $row['cedula']);
    $hojaactiva->setCellValue('B'.$fila, $row['nombre']);
    $hojaactiva->setCellValue('C'.$fila, $row['contrasena']);
    $fila++;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="usuarios.xlsx"');
header('Cache-Control: max-age=0');

$writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
$writer->save('php://output');
exit;
?>
